// import { Injectable, CanActivate, ExecutionContext } from '@nestjs/common';
// import { Observable } from 'rxjs';
// import { UserRoleCodeConstants } from '../../utils/Constants';
// import CommonException from '../../models/CommonException';
// import ErrorCodes from '../../utils/ErrorCodes';

// @Injectable()
// export class FirebaseTokenVerifyGuard implements CanActivate {
//     canActivate(context: ExecutionContext): boolean | Promise<boolean> | Observable<boolean> {
//         const request = context.switchToHttp().getRequest();
//         const userRoles = request.body.requesterUserRoles;
//         if (!userRoles) throw new CommonException(ErrorCodes.INSUFFICIENT_INFORMATION);
//         const isAllowedToAccess = userRoles.includes(UserRoleCodeConstants.ROKKHI_SUPER_ADMIN);
//         if (!isAllowedToAccess) throw new CommonException(ErrorCodes.UNAUTHORIZED_ACCESS);
//         return true;
//     }
// }

// @Injectable()
// export class FirebaseIdTokenVerifyGuard implements CanActivate{
//     canActivate(context: ExecutionContext): boolean | Promise<boolean> | Observable<boolean> {
//         const request = context.switchToHttp().getRequest();
//         const firebaseIdToken = request.body.firebaseId;
        
//     }
// }

// const verifyFirebaseToken = async (authTokenFromFirebase: string) => {
//     let firebaseUid = '';
//     await admin
//         .auth()
//         .verifyIdToken(authTokenFromFirebase)
//         .then(function(decodedToken) {
//             firebaseUid = decodedToken.uid;
//         })
//         .catch(err => {
//             throw new CommonException(ErrorCodes.NOT_AUTHORIZED);
//         });
//     return firebaseUid;
// };