import { DoorSensorRepository } from './repositories/DoorSensorRepository';
import { Module } from '@nestjs/common';
import { SensorService } from './sensor.service';
import { SensorController } from './sensor.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DeviceRepository } from '../device/repositories/DeviceRepository';
import { UserRepository } from '../user/repositories/UserRepository';
import { NotificationService } from '../notification/notification.service';
import FirebaseNotificationService from '../notification/services/common/firebase.notification.service';
import { DeviceTokenService } from '../device-token/device-token.service';
import { DeviceTokenRepository } from '../device-token/repositories/DeviceTokenRepository';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      DeviceRepository,
      UserRepository,
      DoorSensorRepository,
      DeviceTokenRepository
    ])
  ],
  controllers: [SensorController],
  providers: [SensorService, NotificationService, FirebaseNotificationService, DeviceTokenService],
  exports: [SensorService]
})
export class SensorModule {}
