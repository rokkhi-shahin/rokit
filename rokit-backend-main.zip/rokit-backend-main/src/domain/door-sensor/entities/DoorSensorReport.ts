import { Device } from 'src/domain/device/entities/Device';
import { Column, Entity,ManyToOne } from 'typeorm';
import { BaseDatabaseEntity } from '../../../models/BaseDatabaseEntity';

@Entity({name:'DOOR_SENSOR'})
export class DoorSensorReport extends BaseDatabaseEntity{

    @Column({nullable : false, default: ''})
    sensorData: string

    @Column({nullable: false, default: '' })
    status: string

    @Column({nullable: false, default: '' })
    batteryStatus: string

    @Column({nullable: false, default: '' })
    deviceMacAddress: string
    
    @Column({nullable: false, default: '' })
    ssid: string

    @ManyToOne(() => Device, device=> device.sensorLogs)
    device: Device
}