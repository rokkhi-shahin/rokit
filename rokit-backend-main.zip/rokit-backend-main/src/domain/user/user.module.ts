import { DeviceTokenRepository } from './../device-token/repositories/DeviceTokenRepository';
import { Module } from '@nestjs/common';
import { UserService } from './user.service';
import { UserController } from './user.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserRepository } from './repositories/UserRepository';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      UserRepository,
      DeviceTokenRepository
    ])
  ],
  controllers: [UserController],
  providers: [UserService],
  exports: [UserService]
})
export class UserModule {}
