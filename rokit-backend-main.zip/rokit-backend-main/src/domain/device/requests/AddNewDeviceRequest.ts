import { BaseRequest } from './../../../models/BaseRequest';
import { ApiModelProperty } from '@nestjs/swagger/dist/decorators/api-model-property.decorator';
import { IsNotEmpty } from 'class-validator';
export class AddNewDeviceRequest extends BaseRequest{
    // @ApiModelProperty()
    // deviceId: number;

    @ApiModelProperty()
    @IsNotEmpty()
    deviceMacAddress: string;

    @ApiModelProperty()
    @IsNotEmpty()
    deviceType: string;

    @ApiModelProperty()
    @IsNotEmpty()
    deviceName: string;

    @ApiModelProperty()
    @IsNotEmpty()
    deviceAuthorizationCode: string;
}