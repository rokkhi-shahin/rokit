import { Controller } from '@nestjs/common';

@Controller('notification')
export class NotificationController {}
