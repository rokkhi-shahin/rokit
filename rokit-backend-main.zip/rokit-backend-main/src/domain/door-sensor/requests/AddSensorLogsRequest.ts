import { ApiModelProperty } from '@nestjs/swagger/dist/decorators/api-model-property.decorator';
import { IsNotEmpty } from 'class-validator';
export class AddSensorLogsRequest {

    @ApiModelProperty()
    sensorData: string;

    @ApiModelProperty()
    @IsNotEmpty()
    status: string;

    @ApiModelProperty()
    @IsNotEmpty()
    batteryStatus: string;

    @ApiModelProperty()
    @IsNotEmpty()
    deviceMacAddress: string;

    @ApiModelProperty()
    @IsNotEmpty()
    ssid: string;

}