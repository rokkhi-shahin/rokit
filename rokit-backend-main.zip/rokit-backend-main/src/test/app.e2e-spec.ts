import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, LoggerService } from "@nestjs/common";
import * as request from 'supertest'
import { UserModule } from 'src/domain/user/user.module';
import CommonException from 'src/models/CommonException';

class UserTestLogger implements LoggerService{
    log(message: string){}
    error(message: string, trace: string){}
    warn(message: string){}
    debug(message: string){}
    verbose( message: string){}
}

describe('UserController (e2e)', ()=>{
    let user: INestApplication

    beforeAll( async ()=>{
        const moduleFixture: TestingModule = await Test.createTestingModule({
            imports: [UserModule, CommonException],
        }).compile()

        user = moduleFixture.createNestApplication()
        user.useLogger( new UserTestLogger())
        await user.init()
    })
    afterAll( async ()=>{
        await Promise.all([
            user.close(),
        ])
    })

    it('/POST User Details', async ()=>{
        const response = await request(user.getHttpServer())
        .post('/api​/v1​/user​/getUserDetails')
        .send({ requesterFirebaseId: 'gsdjfgcjbhfgwu6464csc', deviceToken: 'sfhkjhEHJKHXHHWkhkhkhHkhouijeoiwquuOEUJOjoIHJhyEdhiHHEDiuhiohxijhIKHRIUhiHJhihrihdiHHRIhIHZsihrihIHjkhberh'})
        .expect(201)
    expect(response.body.requesterFirebaseId).not.toBeDefined()
    })
    it('/POST User Details', async ()=>{
        const response = await request(user.getHttpServer())
        .post('/api​/v1​/user​/getUserDetails')
        .send({ requesterFirebaseId: 'x3nUrfG9Yee6DQa2vqmA43gGVsx1', deviceToken: 'fFHAYl8gRri6mgZ267ZvEJ:APA91bG6e9qtwW9BWR9X4SIpIWP0EUMwbP_7qApyl9PiQGVpAibCIxAg7FXcz23wLwobhRIAQvaJ6sTkHxRQzQiSl7Ypgk2EzGTGFbEWyCpILG5VKTTMrRQuoqaR8iEoD7JkCVZ5zTyq'})
        .expect(201)
    expect(response.body.requesterFirebaseId).not.toBeDefined()
    })
})