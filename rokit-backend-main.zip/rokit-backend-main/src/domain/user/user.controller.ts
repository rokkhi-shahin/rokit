import { Body, Controller, Post, Res } from '@nestjs/common';
import { ApiHeader, ApiTags } from '@nestjs/swagger';
import { SuccessResponse } from 'src/models/SuccessResponse';
import { CreateUserRequest } from './requests/CreateUserRequest';
import { GetUserDetailsRequest } from './requests/GetUserDetailsRequest';
import { UserService } from './user.service';

@ApiTags('User')
@ApiHeader({ name: 'firebaseToken' })
@Controller('user')
export class UserController {
    constructor( private userService: UserService){}

    @Post('getUserDetails')
    async getUserDetails( @Body() request: GetUserDetailsRequest, @Res() response){
        const result = await this.userService.getUserDetails(request);
        response.json(new SuccessResponse(result.getValue()));
    }

    @Post('registerOrUpdate')
    async registerOrUpdateUser(@Body() request: CreateUserRequest, @Res() response){
        if(request.userId){
            const result = await this.userService.updateUser(request)
            response.json(new SuccessResponse(result.getValue()));
        }else{
            const result = await this.userService.createUser(request)
            response.json(new SuccessResponse(result.getValue()));
        }
    }
}
