import { DoorSensorRepository } from '../../door-sensor/repositories/DoorSensorRepository';
import { DoorSensorReport } from "src/domain/door-sensor/entities/DoorSensorReport";
import { EntityRepository, Repository } from "typeorm";
import { Device } from "../entities/Device";

@EntityRepository(Device)
export class DeviceRepository extends Repository<Device>{
    public getSpecificDeviceOfUser = async (userId, deviceType) => {
    let qb = this.createQueryBuilder('t').innerJoin("t.user", "user", "user.id = :uId", {uId: userId});
    if(deviceType){
        qb = qb.andWhere("t.deviceType = :dType", {dType: deviceType});
    }
        return qb.getMany();
    }
    public checkExistingDeviceOfUser = async (firebaseId, deviceMacAddress) => {
        let qb = this.createQueryBuilder('t').leftJoin("t.user", "user", "user.firebaseId = :requesterFirebaseId", {requesterFirebaseId: firebaseId});
        qb = qb.where("t.deviceMacAddress = :dMacAddress", {dMacAddress: deviceMacAddress});
        return qb.getOne();
    }
}

//.leftJoinAndSelect("t.sensorLogs", "sensorLogs", "ORDER BY sensorLogs.createdDate DESC LIMIT 1");
// leftJoinAndSelect(subQuery => {
//     return subQuery
//       .from(Message, "message")
//       .innerJoin('message.chat', 'chat', 'chat.id = :chatId', {chatId: <???>})
//       .innerJoin('message.holders', 'holders', 'holders.id = :userId', {userId: currentUser.id})
//       .orderBy({"message.createdAt": "DESC"});
//   }, "messages")
//.leftJoin("t.user", "user", "user.id = :uId", {uId: userId});