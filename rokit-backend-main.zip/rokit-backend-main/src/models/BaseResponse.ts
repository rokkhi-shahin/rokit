export class BaseResponse {
    public status = '';
    public statusCode = 200;
    public message?: string = '';

    constructor() {}
}
