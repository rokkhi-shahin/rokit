import { TypeOrmModule } from '@nestjs/typeorm';
import { Module } from '@nestjs/common';
import { DeviceService } from './device.service';
import { DeviceController } from './device.controller';
import { DeviceRepository } from './repositories/DeviceRepository';
import { UserRepository } from '../user/repositories/UserRepository';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      DeviceRepository,
      UserRepository
    ])
  ],
  controllers: [DeviceController],
  providers: [DeviceService],
  exports : [DeviceService]
})
export class DeviceModule {}
