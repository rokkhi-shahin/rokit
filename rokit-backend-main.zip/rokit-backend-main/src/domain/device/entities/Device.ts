import { DoorSensorReport } from 'src/domain/door-sensor/entities/DoorSensorReport';
import { User } from 'src/domain/user/entities/User';
import { Column, Entity, ManyToMany, OneToMany } from 'typeorm';
import { BaseDatabaseEntity } from '../../../models/BaseDatabaseEntity';
import { DeviceType } from './DeviceType';

@Entity({name:'DEVICE'})
export class Device extends BaseDatabaseEntity{

    @Column({ nullable : false, default: '' ,unique:true})
    deviceMacAddress: string;

    @Column({ nullable : false, default: '' })
    deviceAuthorizationCode: string;

    @Column({ nullable: true, type:'enum', enum: DeviceType })
    deviceType: string;
    
    @Column({ nullable: false, default: '', unique: true })
    deviceName: string;

    @Column({ nullable: false, default: '' })
    status: string;

    @Column({ nullable: false, default: '' })
    batteryStatus: string;
    
    @ManyToMany(
        () => User, 
        user => user.devices,
        { eager: false}
    )
    user: User[];

    @OneToMany(
        ()=> DoorSensorReport,
        sensor => sensor.device,
        {eager: false}
    )
    sensorLogs: DoorSensorReport[];
  
}