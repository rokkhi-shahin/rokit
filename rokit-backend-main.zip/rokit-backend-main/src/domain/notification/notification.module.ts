import { Module } from '@nestjs/common';
import { NotificationService } from './notification.service';
import { NotificationController } from './notification.controller';
import FirebaseNotificationService from './services/common/firebase.notification.service';
import { DeviceTokenService } from '../device-token/device-token.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { DeviceTokenRepository } from '../device-token/repositories/DeviceTokenRepository';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      DeviceTokenRepository
    ])
  ],
  providers: [NotificationService,FirebaseNotificationService,DeviceTokenService],
  controllers: [NotificationController],
  exports: [NotificationService]
})
export class NotificationModule {}
