import { Injectable } from '@nestjs/common';
import admin from 'firebase-admin';

@Injectable()
export default class FirebaseNotificationService {
    notification_options = {
        priority: 'high',
        timeToLive: 60 * 60 * 24
    };

    sendNotification(deviceToken, message) {
        if (deviceToken.length > 0) {
            admin
                .messaging()
                .sendToDevice(deviceToken, message, this.notification_options)
                .then(response => console.log('Notification sent  ', response))
                .catch(error => console.log(error));
        }
    }
}
