import { MiddlewareConsumer, Module, NestModule, RequestMethod } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { ScheduleModule } from '@nestjs/schedule';
import { UserModule } from './domain/user/user.module';
import { DeviceModule } from './domain/device/device.module';
import { SensorModule } from './domain/door-sensor/sensor.module';
import { AuthorizationMiddleware } from './middlewares/authorization.middleware';
import { NotificationModule } from './domain/notification/notification.module';
import { DeviceTokenModule } from './domain/device-token/device-token.module';
import { ImageModule } from './domain/image/image.module';

@Module({
  imports: [
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule, ScheduleModule.forRoot()],
      useFactory: (configService: ConfigService) => ({
          type: 'postgres',
          host: configService.get('DB_URL'),
          port: +configService.get<number>('DB_PORT'),
          username: configService.get('DB_USER_NAME'),
          password: configService.get('DB_PASSWORD'),
          database: configService.get('DB_NAME'),
          entities: [__dirname + '/**/entities/*{.ts,.js}'],
          synchronize: true
          //autoLoadEntities:true
      }),
      inject: [ConfigService]
  }),
  ConfigModule.forRoot({
    isGlobal: true,
    envFilePath: `env/${process.env.NODE_ENV || 'development'}.env`
  }),
  UserModule,
  DeviceModule,
  SensorModule,
  NotificationModule,
  DeviceTokenModule,
  ImageModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule implements NestModule {
  configure(consumer : MiddlewareConsumer){
    consumer
      .apply(AuthorizationMiddleware)
      .exclude(
        { path: 'api/v1/door-sensor/addSensorLogs', method: RequestMethod.POST },
    )
      .forRoutes('*')
  }
}
