import { Controller } from '@nestjs/common';

@Controller('device-token')
export class DeviceTokenController {}
