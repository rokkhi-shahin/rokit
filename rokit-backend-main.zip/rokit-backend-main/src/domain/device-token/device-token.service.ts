import { Injectable } from '@nestjs/common';
import { Result } from 'src/models/Result';
import { Any } from 'typeorm';
import { DeviceTokenRepository } from './repositories/DeviceTokenRepository';

@Injectable()
export class DeviceTokenService {
    constructor(
        private readonly deviceTokenRepository: DeviceTokenRepository
    ){}
    async getDeviceTokensOfSomeUsers(useridList: any[]) {
        const deviceTokenList = await this.deviceTokenRepository.find({ user: Any(useridList) });
        return Result.success(deviceTokenList.map(d => d.deviceToken));
    }
}
