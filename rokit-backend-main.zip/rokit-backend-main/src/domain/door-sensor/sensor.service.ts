import { DoorSensorReport } from 'src/domain/door-sensor/entities/DoorSensorReport';
import { AddSensorLogsRequest } from './requests/AddSensorLogsRequest';
import { DoorSensorRepository } from './repositories/DoorSensorRepository';
import { Injectable } from '@nestjs/common';
import { DeviceRepository } from '../device/repositories/DeviceRepository';
import { UserRepository } from '../user/repositories/UserRepository';
import { Result } from 'src/models/Result';
import ErrorCodes from 'src/utils/ErrorCodes';
import { GetDeviceSensorsRequest } from './requests/GetDeviceSensorsRequest';
import CommonException from 'src/models/CommonException';
import { NotificationService } from '../notification/notification.service';

@Injectable()
export class SensorService {
    constructor( 
        private sensorRepository: DoorSensorRepository,
        private deviceRepository: DeviceRepository, 
        private userRepository: UserRepository,
        private notificationService: NotificationService
    ){}

    async addSensorLogs(request: AddSensorLogsRequest): Promise<Result>{
       
        const device = await this.deviceRepository.findOne({
            where: { deviceMacAddress: request.deviceMacAddress },
            relations: ['user']
        })
        if(!device) throw new CommonException(ErrorCodes.DEVICE_ALREADY_EXISTS); 
        device['batteryStatus'] = request.batteryStatus;
        device['status'] = request.status;
        const sensor = new DoorSensorReport();
        sensor.sensorData = request.sensorData;
        sensor.deviceMacAddress = request.deviceMacAddress;
        sensor.status = request.status;
        sensor.ssid = request.ssid;
        sensor.batteryStatus = request.batteryStatus;
        sensor.device = device;
        const saveSensorLogsResponse = await this.sensorRepository.save(sensor).then();
        if(device.user.length){
            const userList = device.user.map(u=>u.id)
            this.notificationService.NotifyDeviceUsersAboutNewSensorLogs(userList, device.deviceName, sensor.status)
        }
        await this.deviceRepository.save(device);
        delete(saveSensorLogsResponse.device);
        return Result.success(saveSensorLogsResponse);
    }

    async getDeviceSensors( request: GetDeviceSensorsRequest): Promise<Result>{
        const validUser = await this.userRepository.findOne({
            where: { firebaseId: request.requesterFirebaseId }
        })
        if(!validUser) throw new CommonException(ErrorCodes.INVALID_FIREBASE_ID);
        const device = await this.deviceRepository.findOne({
            where: { deviceMacAddress: request.deviceMacAddress }
        })
        if(!device) throw new CommonException(ErrorCodes.DEVICE_NOT_FOUND);
        const sensorResponse = await this.sensorRepository.getSensorsOfDevice(request.deviceMacAddress, request.fromDate, request.toDate);
        return Result.success(sensorResponse);

    }

}
