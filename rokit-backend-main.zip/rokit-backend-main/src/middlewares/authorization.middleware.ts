import { Injectable, NestMiddleware } from "@nestjs/common";
import { Request, Response } from 'express';
import * as admin from 'firebase-admin'
import CommonException from "src/models/CommonException";
import ErrorCodes from "src/utils/ErrorCodes";

@Injectable()
export class AuthorizationMiddleware implements NestMiddleware{
    async use(req: Request, res: Response, next: () => void) {
        // console.log("Request",req);
        console.log(req.header('firebaseToken'));
        const firebaseToken : any = req.header('firebaseToken');
        if(!firebaseToken) throw new CommonException(ErrorCodes.FIREBASE_TOKEN_MISSING)
        
        let firebaseId = '';
        await admin
        .auth()
        .verifyIdToken(firebaseToken)
        .then(function(decodedToken) {
            console.log("decodedToken", decodedToken);
            firebaseId = decodedToken.uid;
        })
        .catch(err => {
            console.log("ERRRRRRRRRRRR",err);
            
            throw new CommonException(ErrorCodes.UNAUTHORIZED_FIREBASE_TOKEN);
        });
        console.log("firebaseId",firebaseId);
        
        req.body.requesterFirebaseId= firebaseId; 
        next();
    }
}