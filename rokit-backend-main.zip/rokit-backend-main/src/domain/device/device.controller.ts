import { Body, Controller, Post, Res } from '@nestjs/common';
import { ApiHeader, ApiTags } from '@nestjs/swagger';
import { SuccessResponse } from 'src/models/SuccessResponse';
import { DeviceService } from './device.service';
import { AddNewDeviceRequest } from './requests/AddNewDeviceRequest';
import { DeleteDeviceRequest } from './requests/DeleteDeviceRequest';
import { GetAllDevicesRequest } from './requests/GetAllDevicesRequest';

@ApiTags('Device')
@ApiHeader({ name: 'firebaseToken' })
@Controller('device')
export class DeviceController {
    constructor ( private deviceService: DeviceService){}

    @Post('addOrUpdateDevice')
    async addOrUpdateDevice(@Body() request: AddNewDeviceRequest, @Res() response){
        // if(request.deviceId){
            const result = await this.deviceService.addOrUpdateDevice(request)
            response.json(new SuccessResponse(result.getValue()));
        // }else{
        //     const result = await this.deviceService.addNewDevice(request)
        //     response.json(new SuccessResponse(result.getValue()));
        // }
    }
    @Post('getAllDevices')
    async getAllDevices(@Body() request: GetAllDevicesRequest, @Res() response){
       const result = await this.deviceService.getDevicesOfUser(request)
       response.json(new SuccessResponse(result.getValue())) 
    }

    @Post('deleteDevice')
    async deleteDevice(@Body() request: DeleteDeviceRequest, @Res() response){
       const result = await this.deviceService.deleteDevice(request)
       response.json(new SuccessResponse(result.getValue())) 
    }
}
