import { Result } from './../../models/Result';
import { Injectable } from '@nestjs/common';
import { DeviceRepository } from './repositories/DeviceRepository';
import { Device } from './entities/Device';
import CommonException from 'src/models/CommonException';
import ErrorCodes from 'src/utils/ErrorCodes';
import { UserRepository } from '../user/repositories/UserRepository';
import { AddNewDeviceRequest } from './requests/AddNewDeviceRequest';
import { GetAllDevicesRequest } from './requests/GetAllDevicesRequest';
import { DeleteDeviceRequest } from './requests/DeleteDeviceRequest';

@Injectable()
export class DeviceService {
  constructor(
    private deviceRepository: DeviceRepository,
    private userRepository: UserRepository,
  ) {}

  async addOrUpdateDevice(request: AddNewDeviceRequest): Promise<Result> {
    const user = await this.userRepository.findOne({
      where: { firebaseId: request.requesterFirebaseId },
      relations: ['devices'],
    });
    if (!user) throw new CommonException(ErrorCodes.INVALID_FIREBASE_ID);
    // ------------Update is Desable for now...It has no need so remove but future it can be use----------
    // if(request.deviceId){
    //     let existingDevice = await this.deviceRepository.findOne({
    //         where: { id: request.deviceId }
    //     })
    //     if(!existingDevice) throw new CommonException(ErrorCodes.DEVICE_NOT_FOUND);
    //     existingDevice.deviceName = request.deviceName;
    //     const saveDeviceResponse = this.deviceRepository.save(existingDevice);
    //     return Result.success(saveDeviceResponse);
    // }
    let device = await this.deviceRepository.findOne({
      where: { deviceMacAddress: request.deviceMacAddress },
    });
    if (device) {
      const isUserOwnedRequestDevice = user.devices.find(
        (device) => device.deviceMacAddress === request.deviceMacAddress,
      );
      if (isUserOwnedRequestDevice)
        throw new CommonException(ErrorCodes.DEVICE_ALREADY_EXISTS);
      user.devices.push(device);
      const saveDeviceResponse = await this.userRepository.save(user);
      return Result.success(saveDeviceResponse);
    }
    if (!device) {
      const newDevice = new Device();
      newDevice.deviceName = request.deviceName;
      newDevice.deviceMacAddress = request.deviceMacAddress;
      newDevice.deviceType = request.deviceType;
      newDevice.deviceAuthorizationCode = request.deviceAuthorizationCode;
      newDevice.user = [user];
      const saveDeviceResponse = await this.deviceRepository.save(newDevice);
      delete saveDeviceResponse.user;
      return Result.success(saveDeviceResponse);
    }
  }

  async getDevicesOfUser(request: GetAllDevicesRequest): Promise<Result> {
    const validUser = await this.userRepository.findOne({
      where: { firebaseId: request.requesterFirebaseId },
    });
    if (!validUser) throw new CommonException(ErrorCodes.INVALID_FIREBASE_ID);
    const deviceResponse = await this.deviceRepository.getSpecificDeviceOfUser(
      validUser.id,
      request.deviceType,
    );
    return Result.success(deviceResponse);
  }

  async deleteDevice(request: DeleteDeviceRequest): Promise<Result> {
    const user = await this.userRepository.findOne({
      where: { firebaseId: request.requesterFirebaseId },
      relations: ['devices'],
    });
    if (!user) throw new CommonException(ErrorCodes.INVALID_FIREBASE_ID);
    const device = user.devices.find(
      (device) => device.id === request.deviceId,
    );
    if (!device) throw new CommonException(ErrorCodes.DEVICE_NOT_FOUND);
    user['devices'] = user.devices.filter(
      (device) => device.id !== request.deviceId,
    );
    const deviceDeleteResponse = await this.userRepository.save(user);
    return Result.success(deviceDeleteResponse);
  }
}
