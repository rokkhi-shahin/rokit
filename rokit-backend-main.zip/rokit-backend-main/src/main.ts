import { ConfigService } from '@nestjs/config';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ServiceAccount } from 'firebase-admin';
import * as admin from 'firebase-admin';
import { setupSwagger } from './plugins/swagger.plugin';
import { ExceptionsFilter } from './middlewares/exception.filter';
import { ValidationPipe } from '@nestjs/common';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const configService = app.get(ConfigService);
  console.log('Current Environment is ', process.env.NODE_ENV);

  initializeFirebaseAdmin(configService);
  app.setGlobalPrefix('api/v1');
  await setupSwagger(app);
  app.useGlobalFilters(new ExceptionsFilter());
  app.useGlobalPipes(new ValidationPipe({ transform: true }));
  app.enableCors();

  await app.listen(configService.get('PORT'));
}

function initializeFirebaseAdmin(configService) {
  const adminConfig: ServiceAccount = {
      projectId: configService.get('FIREBASE_PROJECT_ID'),
      privateKey: configService.get('FIREBASE_PRIVATE_KEY'),
      clientEmail: configService.get('FIREBASE_CLIENT_EMAIL'),
  };

  admin.initializeApp({
      credential: admin.credential.cert(adminConfig),
      databaseURL: configService.get('FIREBASE_DATABASE_URL')
  });
}
bootstrap();
