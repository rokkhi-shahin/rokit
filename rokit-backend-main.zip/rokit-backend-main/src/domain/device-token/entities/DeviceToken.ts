import { User } from 'src/domain/user/entities/User';
import { BaseDatabaseEntity } from "src/models/BaseDatabaseEntity";
import { Column, Entity, ManyToOne } from "typeorm";

@Entity('DEVICE_TOKEN')
export class DeviceToken extends BaseDatabaseEntity{
    @Column({nullable:false, default:''})
    deviceName: string;

    @Column({nullable:false})
    deviceToken: string;

    @ManyToOne(
        ()=>User,
        user=> user.deviceToken
        )
    user: User
}