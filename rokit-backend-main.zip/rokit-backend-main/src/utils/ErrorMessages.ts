import ErrorCodes from './ErrorCodes';

export default class ErrorMessages {
    static getMessage(errorCode: number) {
        switch (errorCode) {
            case ErrorCodes.USER_ALREADY_EXISTS:
                return 'User Already Exists';
            case ErrorCodes.USER_NOT_FOUND:
                return 'User Not Found';
            case ErrorCodes.DEVICE_NOT_FOUND:
                return 'Device Not Found';
            case ErrorCodes.DEVICE_ALREADY_EXISTS:
                return 'Device Already Added';
            case ErrorCodes.INVALID_FIREBASE_ID:
                return 'Invalid Firebase Id';
            case ErrorCodes.UNAUTHORIZED_FIREBASE_TOKEN:
                return 'Unauthorized Firebase Token';
            case ErrorCodes.INVALID_DATE_FORMAT:
                return 'Date Pick is Badly Formatted';
            case ErrorCodes.FIREBASE_TOKEN_MISSING:
                return 'Firebase Token Header Missing';
            case ErrorCodes.AWS_IMAGE_UPLOAD_FAILED:
                return 'Image Upload Failed';
        }
    }
}
