import { BaseRequest } from './../../../models/BaseRequest';
import { ApiModelProperty } from "@nestjs/swagger/dist/decorators/api-model-property.decorator";
import { IsNotEmpty } from "class-validator";

export class GetUserDetailsRequest extends BaseRequest {
    @ApiModelProperty()
    @IsNotEmpty()
    deviceToken: string

}