import { DeviceTokenRepository } from './../device-token/repositories/DeviceTokenRepository';
import { DeviceToken } from './../device-token/entities/DeviceToken';
import { Injectable } from '@nestjs/common';
import CommonException from 'src/models/CommonException';
import { Result } from 'src/models/Result';
import ErrorCodes from 'src/utils/ErrorCodes';
import { User } from './entities/User';
import { UserRepository } from './repositories/UserRepository';
import { CreateUserRequest } from './requests/CreateUserRequest';
import { GetUserDetailsRequest } from './requests/GetUserDetailsRequest';
import * as admin from 'firebase-admin';

@Injectable()
export class UserService {
  constructor(private userRepository: UserRepository, private deviceTokenRepository: DeviceTokenRepository) {}

  async getUserDetails(request: GetUserDetailsRequest): Promise<Result> {
    const user = await this.userRepository.findOne({
      where: { firebaseId: request.requesterFirebaseId },
      relations:['devices']
    });
    if (!user)return Result.success({
      isActive: false
    });
    const deviceToken = await this.deviceTokenRepository.findOne({
      where: { deviceToken: request.deviceToken}
    })
    if(!deviceToken){
      let deviceToken = new DeviceToken()
      deviceToken.deviceName = user.name+"'s Logged in Device";
      deviceToken.deviceToken = request.deviceToken;
      deviceToken.user = user;
      console.log(deviceToken);
      
      await this.deviceTokenRepository.save(deviceToken)
    }
      // throw new CommonException(ErrorCodes.USER_NOT_FOUND);
    const deviceCount = {
      'totalDevice': user?.devices.length,
      'totalDoor' : user?.devices.filter(device=>device.deviceType==="DOOR").length,
      'totalWindow': user?.devices.filter(device=>device.deviceType==="WINDOW").length,
    }
    delete user.devices;
    user['isActive'] = true;
    const userDetailsWithDeviceCount = {...user, devices: deviceCount}
    return Result.success(userDetailsWithDeviceCount);
  }


  async createUser(request: CreateUserRequest): Promise<Result> {
    const existingUser = await this.userRepository.findOne({
      where: { firebaseId: request.requesterFirebaseId },
    });
    if (existingUser) throw new CommonException(ErrorCodes.USER_ALREADY_EXISTS);    
    let user = new User();
    user.firebaseId = request.requesterFirebaseId;
    user.name = request.name;
    user.phone = request.phone;
    user.address = request.address;
    user.imageUrl = request.imageUrl;
    const saveUserResponse = await this.userRepository.save(user);
    return Result.success(saveUserResponse);
  }


  async updateUser(request: CreateUserRequest): Promise<Result> {
    
    const complainer = await this.userRepository.findOne({
      where: { id: request.userId },
    });
    if (!complainer) throw new CommonException(ErrorCodes.USER_NOT_FOUND);
    let user = new User();
    user.id = request.userId;
    user.name = request.name;
    user.address = request.address;
    user.imageUrl = request.imageUrl;
    const saveUserResponse = await this.userRepository.save(user);
    return Result.success(saveUserResponse);
  }
}
