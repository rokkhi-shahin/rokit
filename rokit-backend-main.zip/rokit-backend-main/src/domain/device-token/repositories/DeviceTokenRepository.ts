import { DeviceToken } from './../entities/DeviceToken';
import { EntityRepository, Repository } from "typeorm";

@EntityRepository(DeviceToken)
export class DeviceTokenRepository extends Repository<DeviceToken>{}