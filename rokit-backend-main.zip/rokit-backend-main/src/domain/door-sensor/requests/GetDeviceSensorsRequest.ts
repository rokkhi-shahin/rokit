import { BaseRequest } from './../../../models/BaseRequest';
import { IsNotEmpty } from 'class-validator';
import { ApiModelProperty } from "@nestjs/swagger/dist/decorators/api-model-property.decorator";

export class GetDeviceSensorsRequest extends BaseRequest{
    
    @ApiModelProperty()
    @IsNotEmpty()
    deviceMacAddress: string;

    @ApiModelProperty()
    fromDate: string;

    @ApiModelProperty()
    toDate: string;
    
}