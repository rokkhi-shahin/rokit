import { request } from 'express';
import CommonException from 'src/models/CommonException';
import ErrorCodes from 'src/utils/ErrorCodes';
import { EntityRepository, Repository } from 'typeorm';
import { DoorSensorReport } from '../entities/DoorSensorReport';

@EntityRepository(DoorSensorReport)
export class DoorSensorRepository extends Repository<DoorSensorReport> {
    public getSensorsOfDevice = async (deviceMacAddress, fromDate, toDate) => {
        let qb = this.createQueryBuilder('sensor');
        qb = qb.andWhere("sensor.deviceMacAddress = :dMacAddress", {dMacAddress: deviceMacAddress});
        if(fromDate && toDate){
            let beginDate = new Date(`${fromDate} 00:00:00`).toISOString();
            let endDate = new Date(`${toDate} 23:59:59`).toISOString();
            if(endDate<beginDate) throw new CommonException(ErrorCodes.INVALID_DATE_FORMAT)
            qb = qb.andWhere("sensor.createdDate BETWEEN :begin AND :end", {begin:fromDate, end:toDate});
        }
        qb = qb.orderBy({ 'sensor.createdDate': 'DESC'})
        return qb.getMany();
    }
};