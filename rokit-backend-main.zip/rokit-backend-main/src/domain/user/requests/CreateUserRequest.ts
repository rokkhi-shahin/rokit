import { BaseRequest } from './../../../models/BaseRequest';
import { ApiModelProperty } from '@nestjs/swagger/dist/decorators/api-model-property.decorator';
import { IsNotEmpty } from 'class-validator';

export class CreateUserRequest extends BaseRequest{
    
    @ApiModelProperty()
    userId: number;

    @ApiModelProperty()
    @IsNotEmpty()
    name: string

    @ApiModelProperty()
    @IsNotEmpty()
    deviceToken: string

    @ApiModelProperty()
    phone: string

    @ApiModelProperty()
    address: string

    @ApiModelProperty()
    imageUrl: string

}