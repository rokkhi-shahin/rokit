import { DeviceToken } from './../../device-token/entities/DeviceToken';
import { Device } from "src/domain/device/entities/Device";
import { BaseDatabaseEntity } from "src/models/BaseDatabaseEntity";
import { Column, Entity, JoinTable, ManyToMany, OneToMany  } from "typeorm";

@Entity({name: 'USER'})
export class User extends BaseDatabaseEntity{

    @Column({ nullable: false, default: '' })
    firebaseId: string;

    @Column({ default: '' })
    name: string;

    @Column({ default: ''})
    phone: string;

    @Column({ default: ''})
    address: string;

    @Column({ default: '' })
    imageUrl: string;

    @ManyToMany( () => Device, device => device.user)
    @JoinTable()
    devices: Device[]

    @OneToMany( ()=> DeviceToken, deviceToken=> deviceToken.deviceToken)
    deviceToken: DeviceToken[]

}