import { Injectable } from '@nestjs/common';
import { DeviceTokenService } from '../device-token/device-token.service';
import FirebaseNotificationService from './services/common/firebase.notification.service';

@Injectable()
export class NotificationService {
    constructor(
        private firebaseNotificationService: FirebaseNotificationService,
        private deviceTokenService: DeviceTokenService
    ){}
    async NotifyDeviceUsersAboutNewSensorLogs(userId, deviceName, status){
        const deviceTokenList = await this.deviceTokenService.getDeviceTokensOfSomeUsers(userId)
        const message = {
            notification: {
                body: `${deviceName} ${status} now`,
                color:  'red',
                title: 'Device Status Alert',
                sound: 'default'
            }
        };

        this.firebaseNotificationService.sendNotification(deviceTokenList.getValue(), message);
    }
}
