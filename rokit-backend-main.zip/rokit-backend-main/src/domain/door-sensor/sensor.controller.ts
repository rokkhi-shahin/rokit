import { SuccessResponse } from 'src/models/SuccessResponse';
import { AddSensorLogsRequest } from './requests/AddSensorLogsRequest';
import { Body, Controller, Post, Res } from '@nestjs/common';
import { SensorService } from './sensor.service';
import { GetDeviceSensorsRequest } from './requests/GetDeviceSensorsRequest';
import { ApiHeader, ApiTags } from '@nestjs/swagger';

@ApiTags('Sensor')
@Controller('door-sensor')
export class SensorController {
    constructor ( private readonly sensorService: SensorService){}

    @Post('addSensorLogs')
    async addSensorLogs( @Body() request: AddSensorLogsRequest, @Res() response){
        const result = await this.sensorService.addSensorLogs(request);
        response.json( new SuccessResponse(result.getValue()));
    }

    @Post('getDeviceSensors')
    @ApiHeader({ name: 'firebaseToken' })
    async getDeviceSensors(@Body() request: GetDeviceSensorsRequest, @Res() response){
        const result = await this.sensorService.getDeviceSensors(request);
        response.json( new SuccessResponse(result.getValue()));
    }

}
