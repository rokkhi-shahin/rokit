export enum DeviceType {
    DOOR = 'DOOR',
    WINDOW = 'WINDOW'
}
